// Cálculos feitos sobre os impostos do mÊs de março/24, quando for testar usar do mesmo mês. NO DIA DA APRESENTAÇÃO ATUALIZAR OS IMPOSTOS PERANTE O ULTIMO MÊS
// Calculations made on taxes for the month of March/24, when testing using the same month.
// https://www.bv.com.br/bv-inspira/financiamento-para-energia-solar/quanto-gera-um-painel-solar#:~:text=Considerando%20uma%20m%C3%A9dia%20de%207,energia%20necess%C3%A1ria%20para%20a%20resid%C3%AAncia. 
// Esse link é a fonte sobre as informações do painel solar
// This link is the source about solar panel information

import java.util.Scanner;
import Energia.EnergiaComercial;
import Energia.EnergiaComercial2;
import Energia.EnergiaResidencial;
import Energia.EnergiaResidencial2;

public class calculo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Escolha o tipo de conta:");
        System.out.println("1 - Residencial");
        System.out.println("2 - Comercial");
        int escolha = scanner.nextInt();
        
        if (escolha == 1) {
            System.out.println("Digite a quantidade de kWh consumida (Residencial):");
            double qtdKwh = scanner.nextDouble();
            EnergiaResidencial gasto_energia = new EnergiaResidencial();
            EnergiaResidencial2 gasto_energia2 = new EnergiaResidencial2();
            gasto_energia.setKwh(qtdKwh);
            gasto_energia2.setKwh(qtdKwh);
            double energyAmount = gasto_energia.valorKwhResidencial() + gasto_energia2.valorKwhResidencial();
            String formattedEnergyAmount = String.format("%.2f", energyAmount);
            
            System.out.println("Gasto total em R$: " + formattedEnergyAmount);
            System.out.println("Utilizando um painel on-grid de 265 W de potência que geraria mais ou menos 38,16 kWh/mês com 7 horas de luz solar por dia, vc precisaria de " + (Math.ceil(qtdKwh / 38.16)) + " paineis solares para não ter que pagar energia em sua residência");
            
        } else if (escolha == 2) {
            System.out.println("Digite a quantidade de kWh consumida (Comercial):");
            double qtdKwh = scanner.nextDouble();
            EnergiaComercial gasto_energia = new EnergiaComercial();
            EnergiaComercial2 gasto_energia2 = new EnergiaComercial2();
            gasto_energia.setKwh(qtdKwh);
            gasto_energia2.setKwh(qtdKwh);
            double energyAmount = gasto_energia.valorKwhComercial() + gasto_energia2.valorKwhComercial();
            String formattedEnergyAmount = String.format("%.2f", energyAmount);
    
            System.out.println("Gasto total em R$: " + formattedEnergyAmount);
            System.out.println("Utilizando um painel on-grid de 265 W de potência que geraria mais ou menos 38,16 kWh/mês com 7 horas de luz solar por dia, vc precisaria de " + (Math.ceil(qtdKwh / 38.16)) + " paineis solares para não ter que pagar energia em sua residência");

        } else {
            System.out.println("Escolha inválida. Encerrando o programa.");
        }

        scanner.close();
    }
}