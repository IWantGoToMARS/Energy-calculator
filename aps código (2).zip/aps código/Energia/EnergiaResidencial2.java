package Energia;
public class EnergiaResidencial2 {
    private double Kwh;
    public double valorKwh = 0.29967000;              // Calculo do TE - R$0,29967000

    private double Amount;

    public double getAmount() {
        return Amount;
    }

    public void setAmount(double amount) {
        Amount = amount;
    }

    public double getKwh() {
        return Kwh;
    }

    public void setKwh(double kwh) {
        Kwh = kwh;
    }

    public double valorKwhResidencial() {
        if(Kwh >= 91 & Kwh <= 200) {
            double energyCost = Kwh * valorKwh;
            energyCost += energyCost * 0.12;     // 12% ICMS
            energyCost *= 1.0344;                // 3,44% COFINS
            energyCost *= 1.0075;                // 0,75% PIS
            return energyCost;
        }
        else if (Kwh > 201) {
            double energyCost = Kwh * valorKwh;
            energyCost += energyCost * 0.25;     // 12% ICMS
            energyCost *= 1.0344;                // 3,44% COFINS
            energyCost *= 1.0075;                // 0,75% PIS
            return energyCost;
        }
        else if (Kwh > 1 & Kwh <= 90){
            double energyCost = Kwh * valorKwh;
            energyCost *= 1.0344;                // 3,44% COFINS
            energyCost *= 1.0075;                // 0,75% PIS
            return energyCost;
        }
        return Amount;
    }
}
