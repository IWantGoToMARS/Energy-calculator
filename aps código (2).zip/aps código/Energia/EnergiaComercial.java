package Energia;
public class EnergiaComercial {
    private double Kwh;
    public double valorKwh = 0.39828000;                 // Calculo do TUSD - R$0,39828000 

    private double Amount;

    public double getAmount() {
        return Amount;
    }

    public void setAmount(double amount) {
        Amount = amount;
    }

    public double getKwh() {
        return Kwh;
    }

    public void setKwh(double kwh) {
        Kwh = kwh;
    }
    
    public double valorKwhComercial() {
        if(Kwh >= 1) {
            double energyCost = Kwh * valorKwh;
            energyCost += energyCost * 0.18;            // 18% ICMS
            energyCost *= 1.0344;                       // 3,44% COFINS
            energyCost *= 1.0075;                       // 0,75% PIS
            return energyCost;
        }
        else return Kwh;    
    }
}
